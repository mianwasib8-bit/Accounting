/**
 * Accounting System — global UI
 * Theme switch · fixed sidebar · collapse · API helpers
 */
(function () {
  'use strict';

  var THEME_KEY = 'as_theme';
  var base = typeof window.APP_BASE === 'string' ? window.APP_BASE : '';

  window.Apex = {
    base: base,
    url: function (path) {
      if (!path) path = '/';
      if (path.charAt(0) !== '/') path = '/' + path;
      return base + path;
    },
    api: function (path, options) {
      options = options || {};
      options.credentials = 'same-origin';
      options.headers = Object.assign(
        { Accept: 'application/json' },
        options.headers || {}
      );
      return fetch(Apex.url(path), options).then(function (res) {
        return res.json().then(function (data) {
          if (!res.ok && !data.message) {
            data.message = 'Request failed (' + res.status + ')';
          }
          data._status = res.status;
          return data;
        }).catch(function () {
          return { success: false, message: 'Invalid JSON response', _status: res.status };
        });
      });
    },
    toast: function (message, type) {
      type = type || 'info';
      var root = document.getElementById('toast-root');
      if (!root) {
        root = document.createElement('div');
        root.id = 'toast-root';
        document.body.appendChild(root);
      }
      var el = document.createElement('div');
      el.className = 'toast toast-' + type;
      el.textContent = message;
      root.appendChild(el);
      setTimeout(function () {
        el.style.opacity = '0';
        el.style.transition = 'opacity .3s';
        setTimeout(function () { el.remove(); }, 300);
      }, 3200);
    },
    money: function (n) {
      var x = Number(n) || 0;
      return x.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    },
    /**
     * Real-time balance refresh: after any transaction (voucher / purchase / cash)
     * is saved, fetch the latest balance of every visible subsidiary and update
     * the DOM in-place. Also broadcast a custom event so module-specific scripts
     * (e.g. purchase.js, voucher_cash.js) can refresh their local caches.
     */
    refreshBalances: function (ids) {
      try {
        var list = Array.isArray(ids) && ids.length
          ? ids
          : Array.prototype.slice.call(document.querySelectorAll('[data-balance-id]'))
              .map(function (el) { return parseInt(el.getAttribute('data-balance-id'), 10) || 0; })
              .filter(Boolean);

        if (!list.length) {
          // No specific ids — broadcast only
          document.dispatchEvent(new CustomEvent('as:balances-updated', { detail: { ids: [] } }));
          return Promise.resolve();
        }

        // Fetch balances one-by-one (lightweight) or via a single endpoint
        var promises = list.map(function (id) {
          return Apex.api('/api/accounts.php?id=' + encodeURIComponent(id)).then(function (d) {
            if (d && d.success) {
              // Update any DOM element bound to this id
              var nodes = document.querySelectorAll('[data-balance-id="' + id + '"]');
              for (var i = 0; i < nodes.length; i++) {
                nodes[i].textContent = Apex.money(d.balance);
              }
              return d.balance;
            }
            return null;
          }).catch(function () { return null; });
        });
        return Promise.all(promises).then(function (results) {
          document.dispatchEvent(new CustomEvent('as:balances-updated', { detail: { ids: list, balances: results } }));
          return results;
        });
      } catch (e) {
        return Promise.resolve();
      }
    },
    refreshAllBalances: function () {
      // Fetch fresh list of all accounts and update everything bound
      return Apex.api('/api/accounts.php').then(function (d) {
        if (!d || !d.success) return;
        var accs = d.accounts || [];
        var byId = {};
        accs.forEach(function (a) { byId[a.id] = a.balance; });
        // Update any element with data-balance-id
        var nodes = document.querySelectorAll('[data-balance-id]');
        nodes.forEach(function (el) {
          var id = parseInt(el.getAttribute('data-balance-id'), 10) || 0;
          if (id && byId.hasOwnProperty(id)) {
            el.textContent = Apex.money(byId[id]);
          }
        });
        document.dispatchEvent(new CustomEvent('as:balances-updated', { detail: { all: true, byId: byId } }));
      }).catch(function () {});
    },
    qs: function (sel, ctx) {
      return (ctx || document).querySelector(sel);
    },
    qsa: function (sel, ctx) {
      return Array.prototype.slice.call((ctx || document).querySelectorAll(sel));
    },
    getTheme: function () {
      return document.documentElement.getAttribute('data-theme') || 'light';
    },
    setTheme: function (theme) {
      theme = theme === 'dark' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', theme);
      document.body && document.body.setAttribute('data-theme', theme);
      try {
        localStorage.setItem(THEME_KEY, theme);
      } catch (e) {}
      var sw = document.getElementById('theme-switch');
      if (sw) sw.checked = theme === 'dark';
      var label = document.getElementById('theme-switch-label');
      if (label) label.textContent = theme === 'dark' ? 'Dark' : 'Light';
    },
    toggleTheme: function () {
      Apex.setTheme(Apex.getTheme() === 'dark' ? 'light' : 'dark');
    },
  };

  // Theme
  function initTheme() {
    var theme = 'light';
    try {
      theme = localStorage.getItem(THEME_KEY) || 'light';
    } catch (e) {}
    Apex.setTheme(theme);

    var sw = document.getElementById('theme-switch');
    if (sw) {
      sw.checked = Apex.getTheme() === 'dark';
      // change + click both (some browsers flaky with label)
      sw.addEventListener('change', function () {
        Apex.setTheme(sw.checked ? 'dark' : 'light');
      });
      sw.addEventListener('click', function (e) {
        // ensure toggle even if change doesn't fire
        setTimeout(function () {
          Apex.setTheme(sw.checked ? 'dark' : 'light');
        }, 0);
      });
    }

    var wrap = document.getElementById('theme-switch-wrap');
    if (wrap) {
      wrap.addEventListener('click', function (e) {
        if (e.target === sw) return;
        e.preventDefault();
        Apex.toggleTheme();
      });
    }
  }

  // Sidebar toggle (works on desktop + mobile via hamburger)
  function initSidebar() {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebar-overlay');
    var openBtn = document.getElementById('btn-sidebar-open');
    var closeBtn = document.getElementById('btn-sidebar-close');
    var closeDesktop = document.getElementById('btn-sidebar-close-desktop');
    var shell = document.getElementById('app-shell');

    function isDesktop() {
      return window.matchMedia('(min-width: 1024px)').matches;
    }

    function openSidebar() {
      if (!sidebar) return;
      sidebar.classList.add('open');
      if (shell) shell.classList.remove('sidebar-collapsed');
      if (overlay) overlay.classList.add('show');
      document.body.classList.add('sidebar-mobile-open');
      try { localStorage.setItem('as_sidebar', 'open'); } catch (e) {}
    }
    function closeSidebar() {
      if (!sidebar) return;
      sidebar.classList.remove('open');
      if (shell) shell.classList.add('sidebar-collapsed');
      if (overlay) overlay.classList.remove('show');
      document.body.classList.remove('sidebar-mobile-open');
      try { localStorage.setItem('as_sidebar', 'closed'); } catch (e) {}
    }

    if (openBtn) {
      openBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (isDesktop()) {
          if (shell && shell.classList.contains('sidebar-collapsed')) {
            openSidebar();
          } else {
            closeSidebar();
          }
        } else {
          // mobile: ensure it's visible
          if (sidebar.classList.contains('open')) {
            closeSidebar();
          } else {
            openSidebar();
          }
        }
      });
    }
    if (closeBtn) closeBtn.addEventListener('click', function (e) { e.preventDefault(); closeSidebar(); });
    if (closeDesktop) closeDesktop.addEventListener('click', function (e) { e.preventDefault(); closeSidebar(); });
    if (overlay) overlay.addEventListener('click', closeSidebar);

    // Restore previous state on desktop
    try {
      var saved = localStorage.getItem('as_sidebar');
      if (saved === 'closed' && isDesktop() && shell) {
        shell.classList.add('sidebar-collapsed');
      }
    } catch (e) {}

    window.addEventListener('resize', function () {
      if (isDesktop()) {
        if (overlay) overlay.classList.remove('show');
        document.body.classList.remove('sidebar-mobile-open');
      }
    });
  }

  // Nested nav click (hover also via CSS)
  function initNav() {
    Apex.qsa('[data-nav-group]').forEach(function (group) {
      var parent = group.querySelector('[data-nav-parent]');
      if (!parent) return;
      parent.addEventListener('click', function (e) {
        e.preventDefault();
        var open = group.classList.contains('is-open');
        Apex.qsa('[data-nav-group]').forEach(function (g) {
          if (g !== group) {
            g.classList.remove('is-open');
            var p = g.querySelector('[data-nav-parent]');
            if (p) p.setAttribute('aria-expanded', 'false');
          }
        });
        group.classList.toggle('is-open', !open);
        parent.setAttribute('aria-expanded', !open ? 'true' : 'false');
      });
    });
  }

  // Hierarchy toggle on COA
  function initHierarchyToggle() {
    var btn = document.getElementById('btn-toggle-hierarchy');
    var panel = document.getElementById('coa-hierarchy-panel');
    if (!btn || !panel) return;
    btn.addEventListener('click', function () {
      var hidden = panel.classList.toggle('hidden');
      btn.textContent = hidden ? 'Show Hierarchy' : 'Hide Hierarchy';
    });
  }

  /**
   * Enter key → next field (like Tab)
   * Works on all forms: inputs, selects, textareas
   * Last field: if submit button exists, focus/click it; else stay
   * Shift+Enter on textarea still inserts newline
   */
  function initEnterToNextField() {
    function isFocusableField(el) {
      if (!el || el.disabled || el.readOnly) return false;
      if (el.tabIndex < 0) return false;
      if (el.type === 'hidden' || el.type === 'file' || el.type === 'submit' || el.type === 'button' || el.type === 'reset' || el.type === 'checkbox' || el.type === 'radio') {
        return false;
      }
      var tag = (el.tagName || '').toUpperCase();
      return tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA';
    }

    function getFormFields(form) {
      var nodes = form.querySelectorAll('input, select, textarea');
      var list = [];
      for (var i = 0; i < nodes.length; i++) {
        if (isFocusableField(nodes[i])) list.push(nodes[i]);
      }
      return list;
    }

    function focusNext(form, current) {
      var fields = getFormFields(form);
      var idx = fields.indexOf(current);
      if (idx === -1) return false;

      // Prefer next enabled field
      for (var i = idx + 1; i < fields.length; i++) {
        try {
          fields[i].focus();
          if (typeof fields[i].select === 'function' && fields[i].tagName === 'INPUT' && fields[i].type !== 'date' && fields[i].type !== 'number') {
            fields[i].select();
          }
          return true;
        } catch (e) {}
      }

      // No next field → try submit button
      var submit =
        form.querySelector('button[type="submit"]:not([disabled])') ||
        form.querySelector('input[type="submit"]:not([disabled])') ||
        form.querySelector('.btn-primary:not([disabled])') ||
        form.querySelector('.btn-save-dark:not([disabled])');
      if (submit) {
        submit.focus();
        // Do not auto-submit — user presses Enter again to save
        return true;
      }
      return false;
    }

    document.addEventListener(
      'keydown',
      function (e) {
        if (e.key !== 'Enter' && e.keyCode !== 13) return;

        var el = e.target;
        if (!el || !el.closest) return;

        // Allow native submit if already on a submit button
        var tag = (el.tagName || '').toUpperCase();
        if (tag === 'BUTTON' || (tag === 'INPUT' && (el.type === 'submit' || el.type === 'button'))) {
          return;
        }

        // Textarea: Enter = newline, Ctrl/Cmd+Enter = next field
        if (tag === 'TEXTAREA') {
          if (!(e.ctrlKey || e.metaKey)) return;
        }

        var form = el.closest('form');
        if (!form) return;
        if (!isFocusableField(el) && tag !== 'TEXTAREA') return;

        // Move to next field instead of submitting mid-form
        e.preventDefault();
        focusNext(form, el);
      },
      true
    );
  }

  // Voucher List action buttons (View / Print / PDF)
  // Ensures clicks work reliably across all browsers.
  // Note: regular <a href> links already navigate — we only intercept
  // the case when the user might be experiencing a popup blocker
  // or when the click event isn't bubbling naturally. We do NOT
  // preventDefault() on modifier-clicks (Ctrl/Cmd/Shift/middle-click)
  // so users can still open in new tab/window.
  function initVoucherActions() {
    document.addEventListener('click', function (e) {
      var target = e.target.closest('.vch-icon');
      if (!target) return;

      // Allow modifier-clicks (open in new tab, etc.) to work natively
      if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button === 1) {
        return;
      }

      var href = target.getAttribute('href');
      if (!href || href === '#' || href === '') return;

      // Stop the default link navigation — we'll handle it
      e.preventDefault();

      var action = target.getAttribute('data-action') || 'view';
      var typeAttr = target.getAttribute('target');

      if (typeAttr === '_blank' || action === 'print' || action === 'pdf') {
        // Open in new tab — use anchor's natural target=_blank if possible
        var win = window.open(href, '_blank');
        if (!win || win.closed || typeof win === 'undefined') {
          // Popup blocked → navigate current tab as fallback
          window.location.href = href;
        }
      } else {
        // Same-tab navigation
        window.location.href = href;
      }
    });
  }

  function boot() {
    initTheme();
    initSidebar();
    initNav();
    initHierarchyToggle();
    initEnterToNextField();
    initVoucherActions();
  }

  document.addEventListener('DOMContentLoaded', boot);

  // Also run immediately if DOM already ready
  if (document.readyState !== 'loading') {
    boot();
  }
})();
