/**
 * Dashboard charts
 *  - Type-wise 7-day line charts (CRV, CPV, JV, PUR, SAL)
 *  - Voucher mix doughnut (5 categories)
 *  - 7-day cash movement grouped bar
 *  - 7-day sales vs purchases grouped bar
 *  - Combined interactive financial graph (6 months line chart)
 */
(function () {
  if (typeof Chart === 'undefined' || !window.DASHBOARD_DATA) return;

  Chart.defaults.font.family = "'Plus Jakarta Sans', system-ui, sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.color = '#64748b';
  Chart.defaults.borderColor = 'rgba(226,232,240,.8)';

  const d = window.DASHBOARD_DATA;

  function moneyLabel(v) {
    if (v >= 1e7) return (v / 1e7).toFixed(2) + ' Cr';
    if (v >= 1e5) return (v / 1e5).toFixed(2) + ' Lac';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    return v.toFixed(0);
  }

  // Helper: 7-day line chart for a transaction type
  function lineChart(canvasId, label, data, color) {
    var el = document.getElementById(canvasId);
    if (!el) return;
    new Chart(el, {
      type: 'line',
      data: {
        labels: d.series.labels,
        datasets: [{
          label: label,
          data: data,
          borderColor: color,
          backgroundColor: color + '22',
          fill: true,
          tension: 0.35,
          borderWidth: 2.5,
          pointBackgroundColor: color,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: 'rgba(226,232,240,.8)' }, ticks: { callback: moneyLabel } },
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(15,23,42,.95)',
            padding: 10,
            titleFont: { weight: 700 },
            callbacks: {
              label: function (ctx) {
                return label + ': ' + (d.currency || 'Rs.') + ' ' +
                  Number(ctx.parsed.y || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
              },
            },
          },
        },
      },
    });
  }

  // 5 type-wise line charts
  lineChart('chart-crv', 'Cash Receipts (CRV)', d.series.crv, '#10b981');
  lineChart('chart-cpv', 'Cash Payments (CPV)', d.series.cpv, '#f43f5e');
  lineChart('chart-jv',  'Journal Voucher (JV)', d.series.jv,  '#0ea5e9');
  lineChart('chart-pur', 'Purchase Form (PUR)', d.series.pur, '#f59e0b');
  lineChart('chart-sal', 'Sale Form (SAL)',     d.series.sal || [], '#8b5cf6');

  // Voucher Mix doughnut (5 categories)
  var pieEl = document.getElementById('chart-pie');
  if (pieEl) {
    var crv = d.pie.crv || 0;
    var cpv = d.pie.cpv || 0;
    var jv = d.pie.jv || 0;
    var pur = d.pie.pur || 0;
    var sal = d.pie.sal || 0;
    var total = crv + cpv + jv + pur + sal;
    var empty = total === 0;
    new Chart(pieEl, {
      type: 'doughnut',
      data: {
        labels: ['CRV', 'CPV', 'JV', 'PUR', 'SAL'],
        datasets: [{
          data: empty ? [1, 1, 1, 1, 1] : [crv, cpv, jv, pur, sal],
          backgroundColor: empty
            ? ['#e2e8f0', '#cbd5e1', '#f1f5f9', '#e2e8f0', '#cbd5e1']
            : ['#10b981', '#f43f5e', '#0ea5e9', '#f59e0b', '#8b5cf6'],
          borderWidth: 0,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Plus Jakarta Sans', size: 12 } } },
          tooltip: { enabled: !empty },
        },
      },
    });
  }

  // 7-day cash movement grouped bar
  var barEl = document.getElementById('chart-bar');
  if (barEl) {
    new Chart(barEl, {
      type: 'bar',
      data: {
        labels: d.bar.labels,
        datasets: [
          {
            label: 'Receipts',
            data: d.bar.crv,
            backgroundColor: 'rgba(16,185,129,.85)',
            borderWidth: 0,
            maxBarThickness: 28,
          },
          {
            label: 'Payments',
            data: d.bar.cpv,
            backgroundColor: 'rgba(244,63,94,.8)',
            borderWidth: 0,
            maxBarThickness: 28,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: 'rgba(226,232,240,.8)' }, ticks: { callback: moneyLabel } },
        },
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Plus Jakarta Sans', size: 12 } } },
        },
      },
    });
  }

  // Sales vs Purchases 7-day grouped bar
  var svpEl = document.getElementById('chart-bar-svp');
  if (svpEl && d.svp) {
    new Chart(svpEl, {
      type: 'bar',
      data: {
        labels: d.svp.labels,
        datasets: [
          {
            label: 'Sales',
            data: d.svp.sal || [],
            backgroundColor: 'rgba(139,92,246,.85)',
            borderWidth: 0,
            maxBarThickness: 28,
          },
          {
            label: 'Purchases',
            data: d.svp.pur || [],
            backgroundColor: 'rgba(245,158,11,.8)',
            borderWidth: 0,
            maxBarThickness: 28,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: 'rgba(226,232,240,.8)' }, ticks: { callback: moneyLabel } },
        },
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Plus Jakarta Sans', size: 12 } } },
        },
      },
    });
  }

  // Combined interactive financial graph (6-month line chart) - 5 datasets
  var combinedEl = document.getElementById('chart-combined');
  if (combinedEl && d.combined) {
    new Chart(combinedEl, {
      type: 'line',
      data: {
        labels: d.combined.labels,
        datasets: [
          {
            label: 'CRV',
            data: d.combined.crv,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16,185,129,.15)',
            fill: false,
            tension: 0.35,
            borderWidth: 2.5,
            pointRadius: 4,
            pointHoverRadius: 6,
            pointBackgroundColor: '#10b981',
          },
          {
            label: 'CPV',
            data: d.combined.cpv,
            borderColor: '#f43f5e',
            backgroundColor: 'rgba(244,63,94,.15)',
            fill: false,
            tension: 0.35,
            borderWidth: 2.5,
            pointRadius: 4,
            pointHoverRadius: 6,
            pointBackgroundColor: '#f43f5e',
          },
          {
            label: 'JV',
            data: d.combined.jv,
            borderColor: '#0ea5e9',
            backgroundColor: 'rgba(14,165,233,.15)',
            fill: false,
            tension: 0.35,
            borderWidth: 2.5,
            pointRadius: 4,
            pointHoverRadius: 6,
            pointBackgroundColor: '#0ea5e9',
          },
          {
            label: 'PUR',
            data: d.combined.pur,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245,158,11,.15)',
            fill: false,
            tension: 0.35,
            borderWidth: 2.5,
            pointRadius: 4,
            pointHoverRadius: 6,
            pointBackgroundColor: '#f59e0b',
          },
          {
            label: 'SAL',
            data: d.combined.sal || [],
            borderColor: '#8b5cf6',
            backgroundColor: 'rgba(139,92,246,.15)',
            fill: false,
            tension: 0.35,
            borderWidth: 2.5,
            pointRadius: 4,
            pointHoverRadius: 6,
            pointBackgroundColor: '#8b5cf6',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: 'rgba(226,232,240,.8)' }, ticks: { callback: moneyLabel } },
        },
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Plus Jakarta Sans', size: 12 } } },
          tooltip: {
            backgroundColor: 'rgba(15,23,42,.95)',
            padding: 10,
            titleFont: { weight: 700 },
            callbacks: {
              label: function (ctx) {
                return ctx.dataset.label + ': ' + (d.currency || 'Rs.') + ' ' +
                  Number(ctx.parsed.y || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
              },
            },
          },
        },
      },
    });
  }
})();
