<?php
/**
 * Voucher list — shared sequence (CRV + CPV + JV)
 */
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

use App\Core\Database;

$pageTitle = 'Voucher List';
$activePage = 'voucher_list';

$db = Database::getInstance();
$type = strtoupper(trim($_GET['type'] ?? ''));
$params = [];
$sql = 'SELECT vs.*, fy.code AS fy_code,
          CASE
            WHEN vs.voucher_type = \'CRV\' THEN (SELECT total_amount FROM cash_receipt_vouchers WHERE id = vs.voucher_id)
            WHEN vs.voucher_type = \'CPV\' THEN (SELECT total_amount FROM cash_payment_vouchers WHERE id = vs.voucher_id)
            WHEN vs.voucher_type = \'JV\'  THEN (SELECT total_debit FROM journal_vouchers WHERE id = vs.voucher_id)
            WHEN vs.voucher_type = \'PUR\' THEN (SELECT net_amount FROM purchases WHERE id = vs.voucher_id)
            ELSE 0
          END AS total_amount
        FROM voucher_sequence vs
        INNER JOIN financial_years fy ON fy.id = vs.financial_year_id
        WHERE 1=1';
if (in_array($type, ['CRV', 'CPV', 'JV', 'PUR'], true)) {
    $sql .= ' AND vs.voucher_type = :t';
    $params['t'] = $type;
}
$sql .= ' ORDER BY vs.financial_year_id DESC, vs.sequence_no DESC LIMIT 300';
$rows = $db->fetchAll($sql, $params);

$typePill = [
  'CRV' => 'pill-emerald',
  'CPV' => 'pill-rose',
  'JV'  => 'pill-sky',
  'PUR' => 'pill-amber',
];

require dirname(__DIR__, 2) . '/includes/layout_start.php';
?>

<div class="section-head">
  <div>
    <h2>Voucher List</h2>
    <p>Shared sequence across CRV · CPV · JV · PUR</p>
  </div>
  <div class="flex gap-2 flex-wrap">
    <a href="<?= e(url('/modules/vouchers/cash_receipt.php')) ?>" class="btn btn-primary btn-sm">+ CRV</a>
    <a href="<?= e(url('/modules/vouchers/cash_payment.php')) ?>" class="btn btn-secondary btn-sm">+ CPV</a>
    <a href="<?= e(url('/modules/vouchers/journal_voucher.php')) ?>" class="btn btn-secondary btn-sm">+ JV</a>
    <a href="<?= e(url('/modules/inventory/purchase.php')) ?>" class="btn btn-secondary btn-sm">+ PUR</a>
  </div>
</div>

<form method="GET" class="card card-pad mb-4 flex gap-3 flex-wrap items-center">
  <select name="type" class="select" style="max-width:180px">
    <option value="">All types</option>
    <option value="CRV" <?= $type === 'CRV' ? 'selected' : '' ?>>CRV</option>
    <option value="CPV" <?= $type === 'CPV' ? 'selected' : '' ?>>CPV</option>
    <option value="JV"  <?= $type === 'JV'  ? 'selected' : '' ?>>JV</option>
    <option value="PUR" <?= $type === 'PUR' ? 'selected' : '' ?>>PUR</option>
  </select>
  <button class="btn btn-secondary btn-sm" type="submit">Filter</button>
</form>

<div class="card">
  <div class="table-wrap">
    <table class="data">
      <thead>
        <tr>
          <th class="seq-col hide-sequence">Sequence</th>
          <th>Voucher No.</th>
          <th>Type</th>
          <th>FY</th>
          <th>Date</th>
          <th class="text-right">Amount</th>
          <th>Created</th>
          <th class="text-center" style="width:140px">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="empty-state">No vouchers posted yet.</td></tr>
      <?php else: foreach ($rows as $r): ?>
        <tr>
          <td class="num seq-col hide-sequence"><strong>#<?= (int)$r['sequence_no'] ?></strong></td>
          <td><strong class="num"><?= (int)$r['voucher_no'] ?></strong></td>
          <td>
            <span class="pill <?= $typePill[$r['voucher_type']] ?? 'pill-indigo' ?>">
              <?= e($r['voucher_type']) ?>
            </span>
          </td>
          <td><?= e($r['fy_code']) ?></td>
          <td><?= e($r['voucher_date']) ?></td>
          <td class="text-right num"><?= number_format((float)$r['total_amount'], 2) ?></td>
          <td style="font-size:12px;color:var(--muted)"><?= e($r['created_at']) ?></td>
          <td class="text-center" style="white-space:nowrap">
            <a href="<?= e(url('/modules/vouchers/view_voucher.php')) ?>?id=<?= (int)$r['voucher_id'] ?>&type=<?= e($r['voucher_type']) ?>&seq_id=<?= (int)$r['id'] ?>" class="vch-icon vch-view" title="View Voucher" aria-label="View" data-action="view">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
              </svg>
            </a>
            <a href="<?= e(url('/modules/vouchers/print_voucher.php')) ?>?id=<?= (int)$r['voucher_id'] ?>&type=<?= e($r['voucher_type']) ?>&seq_id=<?= (int)$r['id'] ?>&auto=1" class="vch-icon vch-print" title="Print Voucher" aria-label="Print" target="_blank" data-action="print">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
              </svg>
            </a>
            <a href="<?= e(url('/modules/vouchers/print_voucher.php')) ?>?id=<?= (int)$r['voucher_id'] ?>&type=<?= e($r['voucher_type']) ?>&seq_id=<?= (int)$r['id'] ?>&pdf=1" class="vch-icon vch-pdf" title="Download / View PDF (use browser Print → Save as PDF)" aria-label="PDF" target="_blank" data-action="pdf">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
            </a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require dirname(__DIR__, 2) . '/includes/layout_end.php'; ?>
