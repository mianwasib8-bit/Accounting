<?php
/**
 * PDF Voucher — Direct redirect to print-friendly page
 * (Use browser's Print → Save as PDF feature)
 * If you want a real PDF library, install TCPF or Dompdf and
 * generate the PDF here instead of redirecting.
 */
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

use App\Core\Auth;

Auth::requireLogin();

$id = (int)($_GET['id'] ?? 0);
$type = strtoupper(trim($_GET['type'] ?? ''));

if ($id <= 0 || !in_array($type, ['CRV', 'CPV', 'JV', 'PUR', 'SAL'], true)) {
    header('Location: ' . url('/modules/vouchers/list.php'));
    exit;
}

// Direct to print page in PDF mode (shows tip, doesn't auto-print)
header('Location: ' . url('/modules/vouchers/print_voucher.php?id=' . $id . '&type=' . $type . '&pdf=1'));
exit;
