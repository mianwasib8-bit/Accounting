# Accounting System

Professional **Accounting & Voucher Management** suite for Laragon  
(HTML · CSS · Vanilla JS · Core PHP OOP · MySQL)

---

## Features

- Premium login, **flat / sharp-edge** collapsible sidebar (240px), light/dark theme
- **Hamburger toggle (☰)** — smoothly hide/show sidebar from top bar (desktop + mobile)
- **Dynamic Dashboard** with type-wise line charts (CRV · CPV · JV · PUR) + 6-month combined interactive graph
- **Chart of Accounts** — Main → Sub → Subsidiary (auto codes) + opening balance / nature
- **Cash Receipt (CRV)** & **Cash Payment (CPV)** — amount lines / double-entry
- **Journal Voucher (JV)** — Debit = Credit lines
- **Purchase Form (PUR)** — double discount, bill expense, party from Chart of Accounts
- **New Item Adder** — categories + items (code, packing, sale/pur rate, stock)
- Voucher numbers: **1, 2, 3…** per type (reset each Financial Year)
- **Shared sequence** across CRV + CPV + JV + PUR · Ledger · Audit trail
- **Real-time balance refresh** after every save (back-to-back queries)
- **Sequence number hidden** from UI (voucher list, view, print) but kept in DB
- **Colorful action icons** (View / Print / PDF) in voucher list
- **Strict A4 print layout** via `@media print`
- User profile + change password (show/hide on all fields)

---

## Laragon setup

1. Extract project to `C:\laragon\www\Accounting`
2. Start **Apache + MySQL**
3. Import the schema (includes sample data — no migrate files needed):
   - phpMyAdmin → Import → `database/schema.sql`  
   - Or CLI:
     ```bash
     mysql -u root < database/schema.sql
     ```
   - Creates / rebuilds database: **`accounting_system`**
   - Includes CRV, CPV, **JV**, **PUR** tables + sample Chart of Accounts (5 main heads, 7 sub heads, 15 subsidiaries) + sample vouchers
4. Open: `http://localhost/Accounting/login.php`
5. Login:
   - **Username:** `admin`
   - **Password:** `admin123`

> **Note:** Database name is `accounting_system` (config: `config/config.php`).  
> Always use `database/schema.sql` as the single source of truth.

---

## Sample data (auto-loaded on fresh import)

After importing `schema.sql`, the database contains:

| Table | Rows | Notes |
|-------|------|-------|
| main_heads | 5 | Assets / Liabilities / Equity / Income / Expenses |
| sub_heads | 7 | Current Assets, Fixed Assets, etc. |
| subsidiary_heads | 15 | Cash 100k · Bank 250k · AR 50k · Owner Equity 400k + more |
| item_categories | 2 | Cement · Hardware |
| items | 4 | Lucky Cement, DG Khan, Steel Rod, Wire |
| cash_receipt_vouchers | 1 | CRV #1 — Cash sale 25,000 |
| cash_payment_vouchers | 1 | CPV #1 — Office rent 15,000 |
| journal_vouchers | 1 | JV #1 — Salaries 20,000 |
| purchases | 1 | PUR #1 — Cement 14,500 (Credit) |
| voucher_sequence | 4 | Sequence #1-#4 shared |
| ledger | 7 | All double-entry postings |

**Dashboard preview:** Total Cash+Bank = **Rs. 340,000** (105k Cash + 235k Bank)  
**Voucher List:** CRV, CPV, PUR, JV all visible from day 1

---

## Project structure

```
Accounting/
├── app/                 Core · Models · Services (OOP PHP)
├── api/                 JSON endpoints
├── assets/css|js        UI + voucher logic
├── config/config.php    App name, DB credentials
├── database/schema.sql  Full CREATE + sample data (JV + PUR included)
├── includes/            Layout start/end
├── modules/
│   ├── heads/           Main · Sub · Subsidiary · Chart of Accounts
│   ├── vouchers/        CRV · CPV · JV · List · View · Print · PDF
│   ├── inventory/       Categories · Items · Purchase Form
│   └── user/            Profile · Change Password
├── index.php            Dashboard (charts, stats, balances)
├── login.php · logout.php
└── .htaccess
```

---

## Voucher entry (current behaviour)

| Field | Notes |
|-------|--------|
| Voucher No | Auto **1, 2, 3…** · readonly · per type per FY |
| Sequence No | Internal only (hidden from UI) |
| Date | Defaults to today |
| Lines | Min **2 rows** · Account · Narration · Debit · Credit · Prev Bal |
| Save | Enabled only when **Debit = Credit** (JV) or **sides match** (CRV/CPV) |

---

## Default login

| Field | Value |
|-------|--------|
| Username | `admin` |
| Password | `admin123` |

---

## License

Internal / educational use.
