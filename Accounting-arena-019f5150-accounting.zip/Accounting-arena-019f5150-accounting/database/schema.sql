-- ============================================================
-- Accounting System — Complete MySQL Schema (FULL)
-- Import ONLY this file in phpMyAdmin / MySQL CLI
-- Compatible with Laragon · MySQL 5.7+ / MariaDB
-- ============================================================
-- Includes (FRESH DATABASE — first time install):
--   Users, Settings, Financial Years
--   3-level Chart of Accounts (Main → Sub → Subsidiary) EMPTY
--   Cash Receipt Voucher (CRV) master + detail
--   Cash Payment Voucher (CPV) master + detail
--   Journal Voucher (JV) master + detail
--   Purchase Voucher (PUR) master + detail — Chart of Accounts party
--   Sale Voucher (SAL) master + detail — Chart of Accounts party + tax
--   Shared voucher sequence across CRV + CPV + JV + PUR + SAL (per FY)
--   Item Categories + Items master
--   Ledger (double-entry, real-time balances) + Audit Trail
--   Sequence no. preserved in DB (only hidden from UI per requirements)
--   NO default Chart of Accounts / item seeds (create from UI)
--   NO separate migrate files required
-- ============================================================

CREATE DATABASE IF NOT EXISTS accounting_system
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE accounting_system;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS audit_trail;
DROP TABLE IF EXISTS ledger;
DROP TABLE IF EXISTS sale_details;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS purchase_details;
DROP TABLE IF EXISTS purchases;
DROP TABLE IF EXISTS journal_voucher_details;
DROP TABLE IF EXISTS journal_vouchers;
DROP TABLE IF EXISTS cash_payment_voucher_details;
DROP TABLE IF EXISTS cash_payment_vouchers;
DROP TABLE IF EXISTS cash_receipt_voucher_details;
DROP TABLE IF EXISTS cash_receipt_vouchers;
DROP TABLE IF EXISTS voucher_sequence;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS item_categories;
DROP TABLE IF EXISTS subsidiary_heads;
DROP TABLE IF EXISTS sub_heads;
DROP TABLE IF EXISTS main_heads;
DROP TABLE IF EXISTS financial_years;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- Users
-- ------------------------------------------------------------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name     VARCHAR(120) NOT NULL,
  email         VARCHAR(150) NULL,
  phone         VARCHAR(30)  NULL,
  role          ENUM('admin','accountant','viewer') NOT NULL DEFAULT 'accountant',
  avatar        VARCHAR(255) NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin: username=admin  password=admin123 (hash set on first login)
INSERT INTO users (username, password_hash, full_name, email, role) VALUES
('admin', '$2y$10$placeholder.will.be.replaced.on.login', 'System Administrator', 'admin@accounting.local', 'admin');

-- ------------------------------------------------------------
-- Settings (key-value)
-- ------------------------------------------------------------
CREATE TABLE settings (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key   VARCHAR(80)  NOT NULL UNIQUE,
  setting_value TEXT NULL,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO settings (setting_key, setting_value) VALUES
('company_name', 'Accounting System'),
('company_address', ''),
('currency_symbol', 'Rs.'),
('currency_code', 'PKR'),
('fy_start_month', '7'),
('cash_account_code', ''),
('date_format', 'Y-m-d');

-- ------------------------------------------------------------
-- Financial Years (voucher numbers reset each FY)
-- July–June style (Pakistan common); active FY seeded for 2026-2027
-- ------------------------------------------------------------
CREATE TABLE financial_years (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(20)  NOT NULL UNIQUE,
  title       VARCHAR(80)  NOT NULL,
  start_date  DATE NOT NULL,
  end_date    DATE NOT NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 0,
  is_closed   TINYINT(1) NOT NULL DEFAULT 0,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO financial_years (code, title, start_date, end_date, is_active) VALUES
('2025-2026', 'FY 2025-2026', '2025-07-01', '2026-06-30', 0),
('2026-2027', 'FY 2026-2027', '2026-07-01', '2027-06-30', 1);

-- ------------------------------------------------------------
-- Chart of Accounts — Level 1: Main Heads
-- Code auto: 01, 02, 03… (not editable in UI)
-- EMPTY by default — create from UI
-- ------------------------------------------------------------
CREATE TABLE main_heads (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code       VARCHAR(10)  NOT NULL UNIQUE,
  title      VARCHAR(150) NOT NULL,
  is_active  TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_mh_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Level 2: Sub Heads
-- code under main: 01, 02…  · full_code e.g. 0101
-- ------------------------------------------------------------
CREATE TABLE sub_heads (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  main_head_id  INT UNSIGNED NOT NULL,
  code          VARCHAR(10)  NOT NULL,
  full_code     VARCHAR(20)  NOT NULL UNIQUE,
  title         VARCHAR(150) NOT NULL,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_by    INT UNSIGNED NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_sub_per_main (main_head_id, code),
  CONSTRAINT fk_sh_main FOREIGN KEY (main_head_id) REFERENCES main_heads(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_sh_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Level 3: Subsidiary Heads (Ledger Accounts)
-- Code structure: Main(2) + Sub(2) + Subsidiary(5) e.g. 010100001
-- Opening balance / nature set later from Chart of Accounts UI
-- EMPTY by default
-- ------------------------------------------------------------
CREATE TABLE subsidiary_heads (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sub_head_id     INT UNSIGNED NOT NULL,
  code            VARCHAR(10)  NOT NULL,
  full_code       VARCHAR(30)  NOT NULL UNIQUE,
  title           VARCHAR(150) NOT NULL,
  opening_balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  nature          ENUM('Dr','Cr') NOT NULL DEFAULT 'Dr',
  account_type    ENUM('cash','bank','party','general') NOT NULL DEFAULT 'general',
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  created_by      INT UNSIGNED NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_subsi_per_sub (sub_head_id, code),
  CONSTRAINT fk_subsi_sub FOREIGN KEY (sub_head_id) REFERENCES sub_heads(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_subsi_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Shared Voucher Sequence (CRV + CPV + JV common transaction sequence)
-- voucher_no is type-wise per financial year (1, 2, 3…)
-- sequence_no is shared across CRV/CPV/JV within FY
-- ------------------------------------------------------------
CREATE TABLE voucher_sequence (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  sequence_no        INT UNSIGNED NOT NULL,
  voucher_type       ENUM('CRV','CPV','JV','PUR','SAL','BRV','BPV') NOT NULL,
  voucher_id         INT UNSIGNED NOT NULL,
  voucher_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  voucher_date       DATE NOT NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_fy_seq (financial_year_id, sequence_no),
  UNIQUE KEY uq_fy_type_no (financial_year_id, voucher_type, voucher_no),
  KEY idx_voucher_ref (voucher_ref),
  CONSTRAINT fk_seq_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Cash Receipt Voucher (Master)
-- UI: pure double-entry rows (Debit/Credit). cash_account_id inferred from lines.
-- ------------------------------------------------------------
CREATE TABLE cash_receipt_vouchers (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  voucher_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  voucher_date       DATE NOT NULL,
  cash_account_id    INT UNSIGNED NOT NULL COMMENT 'Inferred cash/bank account from lines',
  total_amount       DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  narration          VARCHAR(500) NULL COMMENT 'Optional summary from first line narration',
  status             ENUM('posted','void') NOT NULL DEFAULT 'posted',
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_crv_fy_no (financial_year_id, voucher_no),
  UNIQUE KEY uq_crv_ref (voucher_ref),
  CONSTRAINT fk_crv_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_crv_cash FOREIGN KEY (cash_account_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_crv_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE cash_receipt_voucher_details (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  voucher_id       INT UNSIGNED NOT NULL,
  line_no          SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  subsidiary_id    INT UNSIGNED NOT NULL,
  narration        VARCHAR(500) NULL,
  amount           DECIMAL(18,2) NOT NULL,
  previous_balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_crvd_master FOREIGN KEY (voucher_id) REFERENCES cash_receipt_vouchers(id) ON DELETE CASCADE,
  CONSTRAINT fk_crvd_subsi FOREIGN KEY (subsidiary_id) REFERENCES subsidiary_heads(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Cash Payment Voucher (Master)
-- ------------------------------------------------------------
CREATE TABLE cash_payment_vouchers (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  voucher_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  voucher_date       DATE NOT NULL,
  cash_account_id    INT UNSIGNED NOT NULL COMMENT 'Inferred cash/bank account from lines',
  total_amount       DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  narration          VARCHAR(500) NULL,
  status             ENUM('posted','void') NOT NULL DEFAULT 'posted',
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cpv_fy_no (financial_year_id, voucher_no),
  UNIQUE KEY uq_cpv_ref (voucher_ref),
  CONSTRAINT fk_cpv_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_cpv_cash FOREIGN KEY (cash_account_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_cpv_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE cash_payment_voucher_details (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  voucher_id       INT UNSIGNED NOT NULL,
  line_no          SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  subsidiary_id    INT UNSIGNED NOT NULL,
  narration        VARCHAR(500) NULL,
  amount           DECIMAL(18,2) NOT NULL,
  previous_balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_cpvd_master FOREIGN KEY (voucher_id) REFERENCES cash_payment_vouchers(id) ON DELETE CASCADE,
  CONSTRAINT fk_cpvd_subsi FOREIGN KEY (subsidiary_id) REFERENCES subsidiary_heads(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Journal Voucher (Master) — pure double-entry Dr/Cr lines
-- Shared sequence_no with CRV/CPV; own voucher_no per FY
-- ------------------------------------------------------------
CREATE TABLE journal_vouchers (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  voucher_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  voucher_date       DATE NOT NULL,
  total_debit        DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  total_credit       DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  narration          VARCHAR(500) NULL,
  status             ENUM('posted','void') NOT NULL DEFAULT 'posted',
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_jv_fy_no (financial_year_id, voucher_no),
  UNIQUE KEY uq_jv_ref (voucher_ref),
  CONSTRAINT fk_jv_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_jv_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE journal_voucher_details (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  voucher_id       INT UNSIGNED NOT NULL,
  line_no          SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  subsidiary_id    INT UNSIGNED NOT NULL,
  narration        VARCHAR(500) NULL,
  debit_amount     DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  credit_amount    DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  previous_balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_jvd_master FOREIGN KEY (voucher_id) REFERENCES journal_vouchers(id) ON DELETE CASCADE,
  CONSTRAINT fk_jvd_subsi FOREIGN KEY (subsidiary_id) REFERENCES subsidiary_heads(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Ledger (immutable double-entry journal lines)
-- ------------------------------------------------------------
CREATE TABLE ledger (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  sequence_no        INT UNSIGNED NOT NULL,
  voucher_type       ENUM('CRV','CPV','JV','PUR','SAL','BRV','BPV','OB') NOT NULL,
  voucher_id         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  voucher_date       DATE NOT NULL,
  subsidiary_id      INT UNSIGNED NOT NULL,
  narration          VARCHAR(500) NULL,
  debit              DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  credit             DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  balance_after      DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ledger_account_date (subsidiary_id, voucher_date, id),
  KEY idx_ledger_fy (financial_year_id),
  KEY idx_ledger_ref (voucher_ref),
  CONSTRAINT fk_led_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_led_subsi FOREIGN KEY (subsidiary_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_led_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Audit Trail
-- ------------------------------------------------------------
CREATE TABLE audit_trail (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NULL,
  action      VARCHAR(50)  NOT NULL,
  module      VARCHAR(50)  NOT NULL,
  record_id   VARCHAR(50)  NULL,
  description TEXT NULL,
  ip_address  VARCHAR(45)  NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_audit_module (module, created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Item Categories (user-defined; used by Item Adder)
-- code auto: 01, 02, 03… (2 digits, numeric only)
-- ------------------------------------------------------------
CREATE TABLE item_categories (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code       VARCHAR(10)  NOT NULL UNIQUE,
  title      VARCHAR(150) NOT NULL,
  is_active  TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_itemcat_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Items Master (New Item Adder)
-- item_code auto under category: category(2) + item serial(2) e.g. 0101, 0102
-- No picture field — not required
-- stock / rates managed here; purchase form will fetch later
-- ------------------------------------------------------------
CREATE TABLE items (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id     INT UNSIGNED NOT NULL,
  item_code       VARCHAR(20)  NOT NULL UNIQUE,
  item_name       VARCHAR(200) NOT NULL,
  packing         VARCHAR(80)  NULL COMMENT 'Unit / packing e.g. Bag, Pcs, Box',
  sale_rate       DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  purchase_rate   DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  stock           DECIMAL(18,3) NOT NULL DEFAULT 0.000,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  created_by      INT UNSIGNED NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_items_category (category_id),
  KEY idx_items_name (item_name),
  CONSTRAINT fk_items_category FOREIGN KEY (category_id) REFERENCES item_categories(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_items_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Purchase Form (master + item lines)
-- invoice_no auto 1,2,3… per FY · sequence shared with CRV/CPV/JV
-- bill_no user-entered · cash/credit · party + company
-- Lines: item, packing, batch, qty, rate, double discount → net
-- Footer: total + bill expense → final net
-- ------------------------------------------------------------
CREATE TABLE purchases (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  invoice_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  purchase_date      DATE NOT NULL,
  bill_no            VARCHAR(50) NULL,
  pay_mode           ENUM('Cash','Credit') NOT NULL DEFAULT 'Credit',
  party_id           INT UNSIGNED NOT NULL COMMENT 'Supplier subsidiary head',
  company_name       VARCHAR(150) NULL,
  cash_account_id    INT UNSIGNED NULL COMMENT 'Required when pay_mode=Cash',
  subtotal           DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'Sum of line net amounts',
  bill_expense       DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  net_amount         DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'subtotal + bill_expense',
  narration          VARCHAR(500) NULL,
  status             ENUM('posted','void') NOT NULL DEFAULT 'posted',
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_pur_fy_inv (financial_year_id, invoice_no),
  UNIQUE KEY uq_pur_ref (voucher_ref),
  KEY idx_pur_party (party_id),
  KEY idx_pur_date (purchase_date),
  CONSTRAINT fk_pur_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_pur_party FOREIGN KEY (party_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_pur_cash FOREIGN KEY (cash_account_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_pur_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE purchase_details (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  purchase_id       INT UNSIGNED NOT NULL,
  line_no           SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  item_id           INT UNSIGNED NOT NULL,
  item_code         VARCHAR(20) NOT NULL,
  item_title        VARCHAR(200) NOT NULL,
  packing           VARCHAR(80) NULL,
  batch_no          VARCHAR(50) NULL,
  qty               DECIMAL(18,3) NOT NULL DEFAULT 0.000,
  rate              DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  gross_amount      DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'qty * rate',
  disc1_pct         DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  disc1_amt         DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  amount_after_d1   DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  disc2_pct         DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  disc2_amt         DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  net_amount        DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_purd_master FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
  CONSTRAINT fk_purd_item FOREIGN KEY (item_id) REFERENCES items(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Sale Form (master + item lines)
-- invoice_no auto 1,2,3… per FY · sequence shared with CRV/CPV/JV/PUR
-- bill_no user-entered · cash/credit · party + company
-- Lines: item, packing, batch, qty, sale_rate, single discount → net
-- Footer: subtotal + tax_pct → final net
-- Stock DECREASES on save; sale_rate updated on item
-- ------------------------------------------------------------
CREATE TABLE sales (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  financial_year_id  INT UNSIGNED NOT NULL,
  invoice_no         INT UNSIGNED NOT NULL,
  voucher_ref        VARCHAR(30) NOT NULL,
  sale_date          DATE NOT NULL,
  bill_no            VARCHAR(50) NULL,
  pay_mode           ENUM('Cash','Credit') NOT NULL DEFAULT 'Credit',
  party_id           INT UNSIGNED NOT NULL COMMENT 'Customer subsidiary head',
  company_name       VARCHAR(150) NULL,
  cash_account_id    INT UNSIGNED NULL COMMENT 'Required when pay_mode=Cash',
  subtotal           DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'Sum of line net amounts',
  tax_pct            DECIMAL(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Tax % applied on subtotal',
  tax_amount         DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'subtotal * tax_pct / 100',
  net_amount         DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'subtotal + tax_amount',
  narration          VARCHAR(500) NULL,
  status             ENUM('posted','void') NOT NULL DEFAULT 'posted',
  created_by         INT UNSIGNED NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_sal_fy_inv (financial_year_id, invoice_no),
  UNIQUE KEY uq_sal_ref (voucher_ref),
  KEY idx_sal_party (party_id),
  KEY idx_sal_date (sale_date),
  CONSTRAINT fk_sal_fy FOREIGN KEY (financial_year_id) REFERENCES financial_years(id),
  CONSTRAINT fk_sal_party FOREIGN KEY (party_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_sal_cash FOREIGN KEY (cash_account_id) REFERENCES subsidiary_heads(id),
  CONSTRAINT fk_sal_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE sale_details (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sale_id           INT UNSIGNED NOT NULL,
  line_no           SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  item_id           INT UNSIGNED NOT NULL,
  item_code         VARCHAR(20) NOT NULL,
  item_title        VARCHAR(200) NOT NULL,
  packing           VARCHAR(80) NULL,
  batch_no          VARCHAR(50) NULL,
  qty               DECIMAL(18,3) NOT NULL DEFAULT 0.000,
  rate              DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'sale_rate at time of sale',
  gross_amount      DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'qty * rate',
  disc1_pct         DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  disc1_amt         DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  net_amount        DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT 'after discount',
  CONSTRAINT fk_sald_master FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  CONSTRAINT fk_sald_item FOREIGN KEY (item_id) REFERENCES items(id)
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE TEST DATA (auto-loaded on fresh database import)
--   - 5 Main Heads (Assets, Liabilities, Equity, Income, Expenses)
--   - 7 Sub Heads
--   - 15 Subsidiaries (with opening balances, account_type, nature)
--   - 2 Item Categories + 4 Items
--   - 1 Cash Receipt Voucher CRV (#1, sequence 1)
--   - 1 Cash Payment Voucher CPV (#1, sequence 2)
--   - 1 Purchase PUR (#1, sequence 3, with 2 item lines)
--   - 1 Sale SAL (#1, sequence 5, with 1 item line + 1% tax)
--   - 1 Journal Voucher JV (#1, sequence 4 — Salary)
--   - All ledger entries auto-posted (double-entry, real-time balance)
--   - Admin password will be auto-set on first login to: admin123
--   - Opening balances are set in subsidiary_heads (LedgerService
--     uses opening + sum(ledger) — no separate OB JV needed)
-- ============================================================

-- Resolve FK-safe admin id
SET @admin_id := (SELECT id FROM users WHERE username = 'admin' LIMIT 1);
SET @active_fy_id := (SELECT id FROM financial_years WHERE is_active = 1 LIMIT 1);

-- ------------------------------------------------------------
-- 1) CHART OF ACCOUNTS — Main Heads
-- ------------------------------------------------------------
INSERT INTO main_heads (code, title, created_by) VALUES
  ('01', 'Assets',      @admin_id),
  ('02', 'Liabilities', @admin_id),
  ('03', 'Equity',      @admin_id),
  ('04', 'Income',      @admin_id),
  ('05', 'Expenses',    @admin_id);

-- ------------------------------------------------------------
-- 2) Sub Heads
-- ------------------------------------------------------------
INSERT INTO sub_heads (main_head_id, code, full_code, title, created_by) VALUES
  ((SELECT id FROM main_heads WHERE code='01'), '01', '0101', 'Current Assets',      @admin_id),
  ((SELECT id FROM main_heads WHERE code='01'), '02', '0102', 'Fixed Assets',        @admin_id),
  ((SELECT id FROM main_heads WHERE code='02'), '01', '0201', 'Current Liabilities', @admin_id),
  ((SELECT id FROM main_heads WHERE code='03'), '01', '0301', 'Capital',             @admin_id),
  ((SELECT id FROM main_heads WHERE code='04'), '01', '0401', 'Sales Revenue',       @admin_id),
  ((SELECT id FROM main_heads WHERE code='05'), '01', '0501', 'Operating Expenses',  @admin_id),
  ((SELECT id FROM main_heads WHERE code='05'), '02', '0502', 'Cost of Goods',       @admin_id);

-- ------------------------------------------------------------
-- 3) Subsidiaries (Chart of Accounts leaf accounts)
--    Cash/Bank opening balances → realistic Dashboard
--    Party accounts → Purchase Form dropdown
-- ------------------------------------------------------------
INSERT INTO subsidiary_heads
  (sub_head_id, code, full_code, title, opening_balance, nature, account_type, created_by) VALUES
  -- 0101 Current Assets
  ((SELECT id FROM sub_heads WHERE full_code='0101'), '00001', '010100001', 'Cash in Hand',         100000.00, 'Dr', 'cash',   @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0101'), '00002', '010100002', 'HBL Bank Account',     250000.00, 'Dr', 'bank',   @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0101'), '00003', '010100003', 'Accounts Receivable',   50000.00, 'Dr', 'party',  @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0101'), '00004', '010100004', 'XYZ Customer',             0.00, 'Dr', 'party',  @admin_id),
  -- 0102 Fixed Assets
  ((SELECT id FROM sub_heads WHERE full_code='0102'), '00001', '010200001', 'Office Equipment',         0.00, 'Dr', 'general', @admin_id),
  -- 0201 Current Liabilities
  ((SELECT id FROM sub_heads WHERE full_code='0201'), '00001', '020100001', 'Accounts Payable',         0.00, 'Cr', 'party',  @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0201'), '00002', '020100002', 'Salaries Payable',         0.00, 'Cr', 'general', @admin_id),
  -- 0301 Capital
  ((SELECT id FROM sub_heads WHERE full_code='0301'), '00001', '030100001', 'Owner Equity',        400000.00, 'Cr', 'general', @admin_id),
  -- 0401 Sales Revenue
  ((SELECT id FROM sub_heads WHERE full_code='0401'), '00001', '040100001', 'Sales Revenue',            0.00, 'Cr', 'general', @admin_id),
  -- 0501 Operating Expenses
  ((SELECT id FROM sub_heads WHERE full_code='0501'), '00001', '050100001', 'Rent Expense',             0.00, 'Dr', 'general', @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0501'), '00002', '050100002', 'Utilities Expense',        0.00, 'Dr', 'general', @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0501'), '00003', '050100003', 'Salary Expense',           0.00, 'Dr', 'general', @admin_id),
  -- 0502 Cost of Goods (purchase-related)
  ((SELECT id FROM sub_heads WHERE full_code='0502'), '00001', '050200001', 'Purchases - Cement',       0.00, 'Dr', 'general', @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0502'), '00002', '050200002', 'Purchases - Hardware',     0.00, 'Dr', 'general', @admin_id),
  ((SELECT id FROM sub_heads WHERE full_code='0502'), '00003', '050200003', 'ABC Suppliers',            0.00, 'Cr', 'party',  @admin_id);

-- ------------------------------------------------------------
-- 4) Item Categories
-- ------------------------------------------------------------
INSERT INTO item_categories (code, title, created_by) VALUES
  ('01', 'Cement',   @admin_id),
  ('02', 'Hardware', @admin_id);

-- ------------------------------------------------------------
-- 5) Items (per category)
-- ------------------------------------------------------------
INSERT INTO items
  (category_id, item_code, item_name, packing, sale_rate, purchase_rate, stock, created_by) VALUES
  ((SELECT id FROM item_categories WHERE code='01'), '0101', 'Lucky Cement 50kg',   'Bag', 1200.00, 950.00,  50.000, @admin_id),
  ((SELECT id FROM item_categories WHERE code='01'), '0102', 'DG Khan Cement 50kg', 'Bag', 1180.00, 930.00,  30.000, @admin_id),
  ((SELECT id FROM item_categories WHERE code='02'), '0201', 'Steel Rod 12mm',      'Pcs',  850.00, 650.00, 100.000, @admin_id),
  ((SELECT id FROM item_categories WHERE code='02'), '0202', 'Wire 10 gauge',       'Kg',   420.00, 320.00, 200.000, @admin_id);

-- ------------------------------------------------------------
-- 6) CASH RECEIPT (Seq #1, Voucher #1) — Cash sale to XYZ Customer
--    Dr Cash 25,000 / Cr Sales Revenue 25,000
--    After: Cash=125k, Sales=25k
-- ------------------------------------------------------------
INSERT INTO cash_receipt_vouchers
  (financial_year_id, voucher_no, voucher_ref, voucher_date,
   cash_account_id, total_amount, narration, created_by)
SELECT @active_fy_id, 1, '1', '2026-07-05',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100001'),
       25000.00, 'Cash received from XYZ Customer', @admin_id;

INSERT INTO cash_receipt_voucher_details
  (voucher_id, line_no, subsidiary_id, narration, amount, previous_balance)
SELECT LAST_INSERT_ID(), 1, s.id, 'Sale to XYZ Customer', 25000.00, 0.00
FROM subsidiary_heads s WHERE s.full_code='010100004';

INSERT INTO voucher_sequence
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_no, voucher_ref, voucher_date)
SELECT @active_fy_id, 1, 'CRV', id, 1, '1', '2026-07-05'
FROM cash_receipt_vouchers WHERE voucher_no = 1 AND financial_year_id = @active_fy_id LIMIT 1;

-- Ledger: Cash Dr, Sales Cr
INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 1, 'CRV', crv.id, '1', '2026-07-05',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100001'),
       'Cash received from XYZ Customer', 25000.00, 0.00, 125000.00, @admin_id
FROM cash_receipt_vouchers crv
WHERE crv.voucher_no = 1 AND crv.financial_year_id = @active_fy_id LIMIT 1;

INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 1, 'CRV', crv.id, '1', '2026-07-05',
       (SELECT id FROM subsidiary_heads WHERE full_code='040100001'),
       'Sale to XYZ Customer', 0.00, 25000.00, 25000.00, @admin_id
FROM cash_receipt_vouchers crv
WHERE crv.voucher_no = 1 AND crv.financial_year_id = @active_fy_id LIMIT 1;

-- ------------------------------------------------------------
-- 7) CASH PAYMENT (Seq #2, Voucher #1) — Office rent via HBL Bank
--    Dr Rent 15,000 / Cr Bank 15,000
--    After: Bank=235k, Rent=15k
-- ------------------------------------------------------------
INSERT INTO cash_payment_vouchers
  (financial_year_id, voucher_no, voucher_ref, voucher_date,
   cash_account_id, total_amount, narration, created_by)
SELECT @active_fy_id, 1, '1', '2026-07-08',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100002'),
       15000.00, 'Office rent paid via HBL Bank', @admin_id;

INSERT INTO cash_payment_voucher_details
  (voucher_id, line_no, subsidiary_id, narration, amount, previous_balance)
SELECT LAST_INSERT_ID(), 1, s.id, 'Office rent July 2026', 15000.00, 0.00
FROM subsidiary_heads s WHERE s.full_code='050100001';

INSERT INTO voucher_sequence
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_no, voucher_ref, voucher_date)
SELECT @active_fy_id, 2, 'CPV', id, 1, '1', '2026-07-08'
FROM cash_payment_vouchers WHERE voucher_no = 1 AND financial_year_id = @active_fy_id LIMIT 1;

-- Ledger: Rent Dr, Bank Cr
INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 2, 'CPV', cpv.id, '1', '2026-07-08',
       (SELECT id FROM subsidiary_heads WHERE full_code='050100001'),
       'Office rent July 2026', 15000.00, 0.00, 15000.00, @admin_id
FROM cash_payment_vouchers cpv
WHERE cpv.voucher_no = 1 AND cpv.financial_year_id = @active_fy_id LIMIT 1;

INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 2, 'CPV', cpv.id, '1', '2026-07-08',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100002'),
       'Office rent paid via HBL Bank', 0.00, 15000.00, 235000.00, @admin_id
FROM cash_payment_vouchers cpv
WHERE cpv.voucher_no = 1 AND cpv.financial_year_id = @active_fy_id LIMIT 1;

-- ------------------------------------------------------------
-- 8) PURCHASE (Seq #3, Invoice #1) — Credit purchase from ABC
--    Lines: 10 Lucky Cement @950 + 5 DG Khan Cement @930 = 14,150
--    Bill expense 350 → Net 14,500
--    Ledger: Cr ABC Suppliers 14,500
--    Items stock updated: Lucky +10, DG Khan +5
-- ------------------------------------------------------------
INSERT INTO purchases
  (financial_year_id, invoice_no, voucher_ref, purchase_date, bill_no, pay_mode,
   party_id, company_name, cash_account_id, subtotal, bill_expense, net_amount,
   narration, created_by)
SELECT @active_fy_id, 1, '1', '2026-07-10', 'B-2026-001', 'Credit',
       (SELECT id FROM subsidiary_heads WHERE full_code='050200003'),
       'ABC Trading Co.', NULL, 14150.00, 350.00, 14500.00,
       'Cement purchase bill B-2026-001', @admin_id;

INSERT INTO purchase_details
  (purchase_id, line_no, item_id, item_code, item_title, packing, batch_no,
   qty, rate, gross_amount, disc1_pct, disc1_amt, amount_after_d1,
   disc2_pct, disc2_amt, net_amount)
SELECT LAST_INSERT_ID(), 1, i.id, i.item_code, i.item_name, i.packing, 'BC-001',
       10.000, 950.00, 9500.00, 0.00, 0.00, 9500.00, 0.00, 0.00, 9500.00
FROM items i WHERE i.item_code='0101' LIMIT 1;

INSERT INTO purchase_details
  (purchase_id, line_no, item_id, item_code, item_title, packing, batch_no,
   qty, rate, gross_amount, disc1_pct, disc1_amt, amount_after_d1,
   disc2_pct, disc2_amt, net_amount)
SELECT LAST_INSERT_ID(), 2, i.id, i.item_code, i.item_name, i.packing, 'BC-002',
       5.000, 930.00, 4650.00, 0.00, 0.00, 4650.00, 0.00, 0.00, 4650.00
FROM items i WHERE i.item_code='0102' LIMIT 1;

-- Update item stock
UPDATE items SET stock = stock + 10, purchase_rate = 950.00 WHERE item_code = '0101';
UPDATE items SET stock = stock + 5,  purchase_rate = 930.00 WHERE item_code = '0102';

INSERT INTO voucher_sequence
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_no, voucher_ref, voucher_date)
SELECT @active_fy_id, 3, 'PUR', id, 1, '1', '2026-07-10'
FROM purchases WHERE invoice_no = 1 AND financial_year_id = @active_fy_id LIMIT 1;

-- Ledger: A/P Cr for credit purchase
INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 3, 'PUR', p.id, '1', '2026-07-10',
       (SELECT id FROM subsidiary_heads WHERE full_code='050200003'),
       'Purchase bill B-2026-001 — ABC Suppliers (Cr)', 0.00, 14500.00, 14500.00, @admin_id
FROM purchases p
WHERE p.invoice_no = 1 AND p.financial_year_id = @active_fy_id LIMIT 1;

-- ------------------------------------------------------------
-- 9) SALARY JV (Seq #4, Voucher #1) — Salaries paid from cash
--     Dr Salary 20,000 / Cr Cash 20,000
--     After: Cash=105k, Salary=20k
-- ------------------------------------------------------------
INSERT INTO journal_vouchers
  (financial_year_id, voucher_no, voucher_ref, voucher_date, total_debit, total_credit, narration, created_by)
SELECT @active_fy_id, 1, '1', '2026-07-12', 20000.00, 20000.00,
       'Salaries paid July 2026', @admin_id;

INSERT INTO journal_voucher_details
  (voucher_id, line_no, subsidiary_id, narration, debit_amount, credit_amount, previous_balance)
SELECT LAST_INSERT_ID(), 1, s.id, 'Salary expense', 20000.00, 0.00, 0.00
FROM subsidiary_heads s WHERE s.full_code='050100003';

INSERT INTO journal_voucher_details
  (voucher_id, line_no, subsidiary_id, narration, debit_amount, credit_amount, previous_balance)
SELECT LAST_INSERT_ID(), 2, s.id, 'Salary paid in cash', 0.00, 20000.00, 0.00
FROM subsidiary_heads s WHERE s.full_code='010100001';

INSERT INTO voucher_sequence
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_no, voucher_ref, voucher_date)
SELECT @active_fy_id, 4, 'JV', id, 1, '1', '2026-07-12'
FROM journal_vouchers WHERE voucher_no = 1 AND financial_year_id = @active_fy_id LIMIT 1;

INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 4, 'JV', jv.id, '1', '2026-07-12',
       (SELECT id FROM subsidiary_heads WHERE full_code='050100003'),
       'Salary expense', 20000.00, 0.00, 20000.00, @admin_id
FROM journal_vouchers jv
WHERE jv.voucher_no = 1 AND jv.financial_year_id = @active_fy_id LIMIT 1;

INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 4, 'JV', jv.id, '1', '2026-07-12',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100001'),
       'Salary paid in cash', 0.00, 20000.00, 105000.00, @admin_id
FROM journal_vouchers jv
WHERE jv.voucher_no = 1 AND jv.financial_year_id = @active_fy_id LIMIT 1;

-- ------------------------------------------------------------
-- 10) SALE (Seq #5, Invoice #1) — Credit sale to XYZ Customer
--     Lines: 2 Lucky Cement @1200 with 0% disc → net 2400
--     Subtotal 2400 + 1% tax (24) = Net 2424
--     Ledger: Dr XYZ Customer 2424
--     Items stock decreased: Lucky -2
-- ------------------------------------------------------------
INSERT INTO sales
  (financial_year_id, invoice_no, voucher_ref, sale_date, bill_no, pay_mode,
   party_id, company_name, cash_account_id, subtotal, tax_pct, tax_amount, net_amount,
   narration, created_by)
SELECT @active_fy_id, 1, '1', '2026-07-14', 'INV-2026-001', 'Credit',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100004'),
       'XYZ Customer', NULL, 2400.00, 1.00, 24.00, 2424.00,
       'Sale of 2 Lucky Cement bags to XYZ', @admin_id;

INSERT INTO sale_details
  (sale_id, line_no, item_id, item_code, item_title, packing, batch_no,
   qty, rate, gross_amount, disc1_pct, disc1_amt, net_amount)
SELECT LAST_INSERT_ID(), 1, i.id, i.item_code, i.item_name, i.packing, 'BC-S01',
       2.000, 1200.00, 2400.00, 0.00, 0.00, 2400.00
FROM items i WHERE i.item_code='0101' LIMIT 1;

-- Update item stock (sale decreases stock)
UPDATE items SET stock = stock - 2, sale_rate = 1200.00 WHERE item_code = '0101';

INSERT INTO voucher_sequence
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_no, voucher_ref, voucher_date)
SELECT @active_fy_id, 5, 'SAL', id, 1, '1', '2026-07-14'
FROM sales WHERE invoice_no = 1 AND financial_year_id = @active_fy_id LIMIT 1;

-- Ledger: A/R Dr for credit sale (XYZ Customer is a party with Dr nature)
INSERT INTO ledger
  (financial_year_id, sequence_no, voucher_type, voucher_id, voucher_ref, voucher_date,
   subsidiary_id, narration, debit, credit, balance_after, created_by)
SELECT @active_fy_id, 5, 'SAL', s.id, '1', '2026-07-14',
       (SELECT id FROM subsidiary_heads WHERE full_code='010100004'),
       'Sale invoice INV-2026-001 — XYZ Customer (Dr)', 2424.00, 0.00, 2424.00, @admin_id
FROM sales s
WHERE s.invoice_no = 1 AND s.financial_year_id = @active_fy_id LIMIT 1;

-- ------------------------------------------------------------
-- Final status report
-- ------------------------------------------------------------
SELECT '✅ Accounting System schema + sample data imported' AS status;
SELECT
  (SELECT COUNT(*) FROM main_heads)              AS main_heads,
  (SELECT COUNT(*) FROM sub_heads)               AS sub_heads,
  (SELECT COUNT(*) FROM subsidiary_heads)        AS subsidiaries,
  (SELECT COUNT(*) FROM item_categories)         AS item_categories,
  (SELECT COUNT(*) FROM items)                   AS items,
  (SELECT COUNT(*) FROM voucher_sequence)        AS total_vouchers,
  (SELECT COUNT(*) FROM ledger)                  AS ledger_entries;
